from get_input_args import get_input_args
from get_pet_labels import get_pet_labels
from classify_images import classify_images
from adjust_results4_isadog import adjust_results4_isadog
from calculates_results_stats import calculates_results_stats
from print_results import print_results

in_arg = get_input_args()
results = get_pet_labels(in_arg.dir)
classify_images(in_arg.dir, results, in_arg.arch)
for key in results:
    print('start new key')
    print('key' + key)
    print('results[key]')
    print(results[key])
    print(type(results[key]))
    print('index 0')
    print(results[key][0])
    print(type(results[key][0]))
    print('index 1')
    print(results[key][1])
    print(type(results[key][1]))
    print('index 2')
    print(results[key][2])
    print(type(results[key][2]))
    print('end key')
adjust_results4_isadog(results, in_arg.dogfile)

for key in results:
    print(results[key])
    print(type(results[key]))
    print(results[key][0])
